from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('student/<slug:stud_id>/attendance/', views.attendance, name='attendance'),
    path('student/<slug:stud_id>/<slug:course_id>/attendance/', views.attendance_detail, name='attendance_detail'),
    path('student/<slug:class_id>/timetable/', views.timetable, name='timetable'),
    # path('student/<slug:class_id>/search/', views.student_search, name='student_search'),

    path('student/<slug:stud_id>/marks_list/', views.marks_list, name='marks_list'),

    path('lecturer/<slug:lecturer_id>/<int:choice>/Classes/', views.t_clas, name='t_clas'),
    path('lecturer/<int:assign_id>/Students/attendance/', views.t_student, name='t_student'),
    path('lecturer/<int:assign_id>/ClassDates/', views.t_class_date, name='t_class_date'),
    path('lecturer/<int:ass_c_id>/Cancel/', views.cancel_class, name='cancel_class'),
    path('lecturer/<int:ass_c_id>/attendance/', views.t_attendance, name='t_attendance'),
    path('lecturer/<int:ass_c_id>/Edit_att/', views.edit_att, name='edit_att'),
    path('lecturer/<int:ass_c_id>/attendance/confirm/', views.confirm, name='confirm'),
    path('lecturer/<slug:stud_id>/<slug:course_id>/attendance/', views.t_attendance_detail, name='t_attendance_detail'),
    path('lecturer/<int:att_id>/change_attendance/', views.change_att, name='change_att'),
    path('lecturer/<int:assign_id>/Extra_class/', views.t_extra_class, name='t_extra_class'),
    path('lecturer/<slug:assign_id>/Extra_class/confirm/', views.e_confirm, name='e_confirm'),
    path('lecturer/<int:assign_id>/Report/', views.t_report, name='t_report'),

    path('download-attendance/<int:attendance_class_id>/', views.download_attendance, name='download_attendance'),

    
    path('lecturer/<slug:lecturer_id>/t_timetable/', views.t_timetable, name='t_timetable'),
    path('lecturer/<int:asst_id>/Free_lecturers/', views.free_lecturers, name='free_lecturers'),

    path('lecturer/<int:assign_id>/marks_list/', views.t_marks_list, name='t_marks_list'),
    path('lecturer/<int:assign_id>/Students/Marks/', views.student_marks, name='t_student_marks'),
    path('lecturer/<int:marks_c_id>/marks_entry/', views.t_marks_entry, name='t_marks_entry'),
    path('lecturer/<int:marks_c_id>/marks_entry/confirm/', views.marks_confirm, name='marks_confirm'),
    path('lecturer/<int:marks_c_id>/Edit_marks/', views.edit_marks, name='edit_marks'),

    
    path('attendant/<slug:attendant_id>/<int:choice>/Classes/', views.a_clas, name='a_clas'),
    path('attendant/<int:assign_id>/Students/attendance/', views.a_student, name='a_student'),
    path('attendant/<int:assign_id>/ClassDates/', views.a_class_date, name='a_class_date'),
    path('attendant/<int:ass_c_id>/Cancel/', views.cancel_class, name='cancel_class'),
    path('attendant/<int:ass_c_id>/attendance/', views.a_attendance, name='a_attendance'),
    # path('attendant/<int:ass_c_id>/Edit_att/', views.a_edit_att, name='a_edit_att'),
    path('attendant/<int:ass_c_id>/attendance/confirm/', views.confirm, name='a_confirm'),
    # path('attendant/<slug:stud_id>/<slug:course_id>/attendance/', views.a_attendance_detail, name='a_attendance_detail'),
    # path('attendant/<int:att_id>/change_attendance/', views.a_change_att, name='a_change_att'),
    path('attendant/<int:assign_id>/Extra_class/', views.a_extra_class, name='a_extra_class'),
    # path('attendant/<slug:assign_id>/Extra_class/confirm/', views.a_e_confirm, name='a_e_confirm'),
    
]

